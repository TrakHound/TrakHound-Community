﻿namespace TrakHound_Dashboard.Pages.Cycles.Controls
{
    public class FilterCheckBox : System.Windows.Controls.CheckBox
    {

        public object DataObject { get; set; }

    }
}
