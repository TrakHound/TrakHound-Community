﻿namespace TrakHound_Device_Manager.Pages.InstanceData.Controls
{
    public class CheckBox : System.Windows.Controls.CheckBox
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}
