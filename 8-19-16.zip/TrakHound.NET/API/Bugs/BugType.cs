﻿namespace TrakHound.API
{
    public static partial class Bugs
    {
        public enum BugType
        {
            AUTO_GENERATED,
            USER_SUBMITTED
        }
    }
}
