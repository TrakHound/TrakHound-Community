﻿// Copyright (c) 2016 Feenux LLC, All Rights Reserved.

// This file is subject to the terms and conditions defined in
// file 'LICENSE.txt', which is part of this source code package.

using System;
using System.Xml;
using System.IO;

using TrakHound.Logging;
using TrakHound.Tools;

namespace TrakHound.API.Users
{
    public static class UserLoginFile
    {
        public const string USER_LOGIN_FILENAME = "nigolresu";

        public static bool Create(UserConfiguration userConfig)
        {
            bool result = false;

            FileLocations.CreateAppDataDirectory();
            string path = Path.Combine(FileLocations.AppData, USER_LOGIN_FILENAME);

            Remove(path);

            if (userConfig != null)
            {
                var xml = CreateDocument(userConfig);
                WriteDocument(xml, path);
            }

            return result;
        }

        public class LoginData
        {
            public string Username { get; set; }
            public string Token { get; set; }
        }

        public static LoginData Read()
        {
            LoginData result = null;

            string path = Path.Combine(FileLocations.AppData, USER_LOGIN_FILENAME);
            if (File.Exists(path))
            {
                try
                {
                    var xml = new XmlDocument();
                    xml.Load(path);

                    string username = XML_Functions.GetInnerText(xml, "Username");
                    string token = XML_Functions.GetInnerText(xml, "Token");

                    if (username != null && token != null)
                    {
                        result = new LoginData();
                        result.Username = username;
                        result.Token = token;
                    }
                }
                catch (Exception ex) { Logger.Log("UserLoginFile.Read() :: Exception :: " + ex.Message); }
            }

            return result;
        }


        private static XmlDocument CreateDocument(UserConfiguration userConfig)
        {
            var result = new XmlDocument();

            XmlNode docNode = result.CreateXmlDeclaration("1.0", "UTF-8", null);
            result.AppendChild(docNode);

            XmlNode root = result.CreateElement("UserLogin");
            result.AppendChild(root);

            // Username
            XmlNode username = result.CreateElement("Username");
            username.InnerText = userConfig.Username;
            root.AppendChild(username);

            // Token
            XmlNode token = result.CreateElement("Token");
            token.InnerText = userConfig.Token;
            root.AppendChild(token);

            return result;
        }

        public static void Remove()
        {
            string path = Path.Combine(FileLocations.AppData, USER_LOGIN_FILENAME);
            Remove(path);
        }

        private static void Remove(string path)
        {
            if (File.Exists(path)) File.Delete(path);
        }

        private static void WriteDocument(XmlDocument doc, string path)
        {
            var settings = new XmlWriterSettings();
            settings.Indent = false;

            try
            {
                using (var writer = XmlWriter.Create(path, settings))
                {
                    doc.Save(writer);
                }
            }
            catch (Exception ex) { Logger.Log("UserLoginFile.WriteDocument() :: Exception :: " + ex.Message); }
        }


        public class Monitor
        {
            public delegate void UserChanged_Handler(LoginData loginData);
            public event UserChanged_Handler UserChanged;

            public Monitor()
            {
                string dir = FileLocations.AppData;

                var watcher = new FileSystemWatcher(dir, USER_LOGIN_FILENAME);
                watcher.Changed += File_Changed;
                watcher.Created += File_Changed;
                watcher.Deleted += File_Changed;
                watcher.EnableRaisingEvents = true;
            }

            private void File_Changed(object sender, FileSystemEventArgs e)
            {
                var loginData = Read();

                if (UserChanged != null) UserChanged(loginData);
            }
        }
    }
}
