﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrakHound.Tools
{
    public static class UI_Functions
    {

        public const System.Windows.Threading.DispatcherPriority PRIORITY_DATA_BIND = System.Windows.Threading.DispatcherPriority.DataBind;
        public const System.Windows.Threading.DispatcherPriority PRIORITY_BACKGROUND = System.Windows.Threading.DispatcherPriority.Background;

    }
}
