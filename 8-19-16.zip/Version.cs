﻿using System.Reflection;


[assembly: AssemblyVersion("1.2.17.*")]
[assembly: AssemblyFileVersion("1.2.17.*")]
